# BilgiYarismasi
HTML, CSS, JavaScript, Json, Fetch API ile oluşturulan skor veren ve kaydeden bilgi yarışması.
